# Note: Code from here was imported from BuildStream repo
# See 8c63af1940d5e071cd4e75fa8a45114f952cd784 for details

import threading

from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import ThreadedFTPServer


class SimpleFtpServer(threading.Thread):
    def __init__(self):
        super().__init__()
        self.authorizer = DummyAuthorizer()
        handler = FTPHandler
        handler.authorizer = self.authorizer
        self.server = ThreadedFTPServer(("127.0.0.1", 0), handler)

    def run(self):
        self.server.serve_forever()

    def stop(self):
        self.server.close_all()
        self.join()

    def allow_anonymous(self, cwd):
        self.authorizer.add_anonymous(cwd)

    def add_user(self, user, password, cwd):
        self.authorizer.add_user(user, password, cwd, perm="elradfmwMT")

    def base_url(self):
        return "ftp://127.0.0.1:{}".format(self.server.address[1])
