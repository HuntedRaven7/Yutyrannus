# Pylint doesn't play well with fixtures and dependency injection from pytest
# pylint: disable=redefined-outer-name

import json
import os
import pytest

from buildstream._testing.runcli import (  # pylint: disable=unused-import
    cli_integration as cli,
)
from buildstream._testing.integration import (  # pylint: disable=unused-import
    integration_cache,
)

pytestmark = pytest.mark.integration

DATA_DIR = os.path.join(os.path.dirname(os.path.realpath(__file__)), "project")
MANIFEST_FILES = {
    "source-provenance-spdx": "source-provenance-spdx.json",
    "source-provenance-manifest": "source-provenance-manifest.json",
    "export-manifest-spdx": "export-manifest-spdx.json",
    "export-manifest-manifest": "export-manifest-manifest.json",
}


@pytest.mark.datafiles(DATA_DIR)
def test_collect_manifest(cli, datafiles):
    project = str(datafiles)
    checkout = os.path.join(project, "checkout")

    element_name = "collect_manifest/all-manifests.bst"

    result = cli.run(project=project, args=["build", element_name])
    result.assert_success()

    result = cli.run(
        project=project,
        args=["artifact", "checkout", "--directory", checkout, element_name],
    )
    result.assert_success()

    for _, v in MANIFEST_FILES.items():
        with (
            open(f"{checkout}/{v}", "r", encoding="utf-8") as result_file,
            open(
                f"{project}/expected/collect_manifest/{v}",
                "r",
                encoding="utf-8",
            ) as expected_file,
        ):
            result, expected = json.load(result_file), json.load(expected_file)
            assert result == expected
