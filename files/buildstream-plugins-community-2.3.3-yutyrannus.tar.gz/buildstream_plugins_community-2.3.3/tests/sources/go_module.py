# Copyright (C) 2026 Aleix Pol Gonzalez <aleix.pol@codethink.co.uk>
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library. If not, see <http://www.gnu.org/licenses/>.

import pytest

from buildstream_plugins_community.sources.go_module import VERSION_REGEX


# Test cases extracted from
# https://github.com/golang/mod/blob/master/semver/semver_test.go
@pytest.mark.parametrize(
    "version, tag, major, minor, patch, prerelease, metadata",
    [
        ("v1.0.0-alpha", "v1.0.0-alpha", "v1", "0", "0", "-alpha", None),
        (
            "v1.0.0-alpha.1",
            "v1.0.0-alpha.1",
            "v1",
            "0",
            "0",
            "-alpha.1",
            None,
        ),
        (
            "v1.0.0-alpha.beta",
            "v1.0.0-alpha.beta",
            "v1",
            "0",
            "0",
            "-alpha.beta",
            None,
        ),
        ("v1.0.0-beta", "v1.0.0-beta", "v1", "0", "0", "-beta", None),
        ("v1.0.0-beta.2", "v1.0.0-beta.2", "v1", "0", "0", "-beta.2", None),
        (
            "v1.0.0-beta.11",
            "v1.0.0-beta.11",
            "v1",
            "0",
            "0",
            "-beta.11",
            None,
        ),
        ("v1.0.0-rc.1", "v1.0.0-rc.1", "v1", "0", "0", "-rc.1", None),
        ("v1.0.0", "v1.0.0", "v1", "0", "0", None, None),
        ("v1.2.0", "v1.2.0", "v1", "2", "0", None, None),
        ("v1.2.3-456", "v1.2.3-456", "v1", "2", "3", "-456", None),
        (
            "v1.2.3-456.789",
            "v1.2.3-456.789",
            "v1",
            "2",
            "3",
            "-456.789",
            None,
        ),
        (
            "v1.2.3-456-789",
            "v1.2.3-456-789",
            "v1",
            "2",
            "3",
            "-456-789",
            None,
        ),
        ("v1.2.3-456a", "v1.2.3-456a", "v1", "2", "3", "-456a", None),
        ("v1.2.3-pre", "v1.2.3-pre", "v1", "2", "3", "-pre", None),
        (
            "v1.2.3-pre+meta",
            "v1.2.3-pre",
            "v1",
            "2",
            "3",
            "-pre",
            "+meta",
        ),
        ("v1.2.3-pre.1", "v1.2.3-pre.1", "v1", "2", "3", "-pre.1", None),
        ("v1.2.3-zzz", "v1.2.3-zzz", "v1", "2", "3", "-zzz", None),
        ("v1.2.3", "v1.2.3", "v1", "2", "3", None, None),
        ("v1.2.3+meta", "v1.2.3", "v1", "2", "3", None, "+meta"),
        (
            "v1.2.3+meta-pre",
            "v1.2.3",
            "v1",
            "2",
            "3",
            None,
            "+meta-pre",
        ),
        (
            "v1.2.3+meta-pre.sha.256a",
            "v1.2.3",
            "v1",
            "2",
            "3",
            None,
            "+meta-pre.sha.256a",
        ),
        ("v4.0.0-rc.4", "v4.0.0-rc.4", "v4", "0", "0", "-rc.4", None),
    ],
)
def test_version_regex(
    version, tag, major, minor, patch, prerelease, metadata
):
    match = VERSION_REGEX.fullmatch(version)

    assert match
    assert match.groupdict() == {
        "tag": tag,
        "major": major,
        "minor": minor,
        "patch": patch,
        "prerelease": prerelease,
        "metadata": metadata,
    }


@pytest.mark.parametrize(
    "version",
    [
        "bad",
        "v1-alpha.beta.gamma",
        "v1-pre",
        "v1+meta",
        "v1-pre+meta",
        "v1.2-pre",
        "v1.2+meta",
        "v1.2-pre+meta",
        "v01.2.3",
        "v1.02.3",
        "v1.2.03",
        "v1.2.3-01",
        "v1.2.3-alpha..1",
        "v1.2.3-alpha_1",
        "v1.2.3+meta..build",
        "v1.2.3+meta_build",
    ],
)
def test_invalid_version(version):
    assert VERSION_REGEX.fullmatch(version) is None


# x/mod/semver accepts these as shorthand and canonicalizes them by adding
# the omitted components. Versions read from go.sum are already canonical, so
# VERSION_REGEX deliberately requires all three numeric components.
@pytest.mark.parametrize("version", ["v1", "v1.0", "v1.2"])
def test_noncanonical_version(version):
    assert VERSION_REGEX.fullmatch(version) is None
