#
#  Copyright (C) 2024 Codethink Limited
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU Lesser General Public
#  License as published by the Free Software Foundation; either
#  version 2 of the License, or (at your option) any later version.
#
#  This library is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public
#  License along with this library. If not, see <http://www.gnu.org/licenses/>.
#
#  Authors:
#        Thomas Coldrick <thomas.coldrick@codethink.co.uk>
#

# Pylint doesn't play well with fixtures and dependency injection from pytest
# pylint: disable=redefined-outer-name

import os
import hashlib
from pathlib import Path
from typing import List, Callable, Any
import pytest

from buildstream._testing import cli  # pylint: disable=unused-import
from . import list_dir_contents

DATA_DIR = os.path.join(
    os.path.dirname(os.path.realpath(__file__)),
    "bazel_file",
)

SHA256SUM = "b6256f29acb66e58da643724097190f4db524397541e4e0fd59e63f2eae0df48"
SHA384SUM = "1bae748b78986196bdd4fbb52c7807971b5aeb5d69bf26fd50b15684659f17971f95017752c9eeee2b311944d746c615"
SHA512SUM = "183923f3ad16a35fab4f4f0c821ee2091411b7c764d58985783ecdca9ec8a5d865d891877e94a70d7aa9bbb838d5dc89cc783a1e0b1b58bd4d36a5b4510e85d8"


def id_marker(hasher: Callable[[bytes], Any], canonical_id: str) -> str:
    hash_ = hasher(canonical_id.encode("utf-8")).hexdigest()
    return f"id-{hash_}"


def create_repo_cache(
    cli: Any, project: str, checkoutdir: Path, element_name: str
) -> Path:
    assert element_name.endswith(".bst")

    result = cli.run(
        project=project,
        args=[
            "source",
            "checkout",
            element_name,
            "--directory",
            checkoutdir,
        ],
    )
    result.assert_success()

    return checkoutdir / element_name[:-4] / "_bst_repository_cache"


def repo_cache_sha256(
    cache_dir: Path, sha256sum: str, canonical_ids: List[str]
) -> None:

    checkout_contents = list_dir_contents(
        cache_dir / "content_addressable/sha256" / sha256sum
    )

    print(checkout_contents)

    assert "file" in checkout_contents
    assert "info.txt" in checkout_contents

    for canonical_id in canonical_ids:
        print(f"checking canonical_id '{canonical_id}'")
        assert id_marker(hashlib.sha256, canonical_id) in checkout_contents
        assert id_marker(hashlib.sha384, canonical_id) in checkout_contents
        assert id_marker(hashlib.sha512, canonical_id) in checkout_contents


def repo_cache_link(
    cache_dir: Path, sha256sum: str, hashname: str, hashhex: str
) -> None:
    link_contents = list_dir_contents(
        cache_dir / "content_addressable" / hashname / hashhex
    )
    sha256_contents = list_dir_contents(
        cache_dir / "content_addressable/sha256" / sha256sum
    )

    assert link_contents == sha256_contents


@pytest.mark.datafiles(DATA_DIR)
def test_basic(cli, tmpdir, datafiles):
    project = str(datafiles)
    element_name = "basic.bst"

    result = cli.run(project=project, args=["source", "fetch", element_name])
    assert result.exit_code == 0

    assert cli.get_element_state(project, element_name) == "buildable"

    cache_dir = create_repo_cache(
        cli, project, Path(str(tmpdir)) / "checkout", element_name
    )

    repo_cache_sha256(
        cache_dir,
        SHA256SUM,
        [
            "https://gitlab.com/BuildStream/buildstream-plugins-community/-/raw/ff890206ccea24c30aec9a503c196ad58ef4af83/src/bst_plugins_experimental/sources/bazel_source.py"
        ],
    )

    repo_cache_link(cache_dir, SHA256SUM, "sha384", SHA384SUM)

    repo_cache_link(cache_dir, SHA256SUM, "sha512", SHA512SUM)


@pytest.mark.datafiles(DATA_DIR)
def test_multi_url(cli, tmpdir, datafiles):
    project = str(datafiles)
    element_name = "multi-url.bst"

    result = cli.run(project=project, args=["source", "fetch", element_name])
    assert result.exit_code == 0

    assert cli.get_element_state(project, element_name) == "buildable"

    cache_dir = create_repo_cache(
        cli, project, Path(str(tmpdir)) / "checkout", element_name
    )

    repo_cache_sha256(
        cache_dir,
        SHA256SUM,
        [
            "https://gitlab.com/BuildStream/buildstream-plugins-community/-/raw/ff890206ccea24c30aec9a503c196ad58ef4af83/src/bst_plugins_experimental/sources/bazel_source.py https://gitlab.com/BuildStream/buildstream-plugins-community/-/raw/81dc02c3022418cf4ba6c094906a5c84b2b14961/src/bst_plugins_experimental/sources/bazel_source.py"
        ],
    )

    repo_cache_link(cache_dir, SHA256SUM, "sha384", SHA384SUM)

    repo_cache_link(cache_dir, SHA256SUM, "sha512", SHA512SUM)
