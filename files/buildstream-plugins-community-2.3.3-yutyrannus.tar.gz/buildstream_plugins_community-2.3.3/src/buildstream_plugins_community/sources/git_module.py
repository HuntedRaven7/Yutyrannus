"""
git-module - extension of BuildStream git plugin to track submodules
====================================================================

This source plugin is intended to be used in the list of sources after another git plugin, 
such as git_repo or git_tag. 
The plugin tracks sources for the submodule at the `path` in the previously staged sources.

**Host dependencies**

  * git

**Usage:**

.. code:: yaml

   # Specify the git_module source kind
   kind: git_module

   # Specific the path to the submodule
   # path: path/to/submodule

   # Optionally specify a relative staging directory
   # directory: path/to/stage

   # Specify the repository url, using an alias defined
   # in your project configuration is recommended
   url: upstream:foo.git

   # Specify the commit ref, this must be specified in order to
   # checkout sources and build, but can be automatically updated
   # if the 'track' attribute was specified.
   ref: d63cbb6fdc0bbdadc4a1b92284826a6d63a7ebcd

   # Optionally specify whether or not to clone Git LFS objects
   use-lfs: False

   # Fetch a full clone instead of a shallow clone.
   full-clone: False

   # Modify the default version guessing pattern
   #
   version-guess-pattern: \'(\\d+)\\.(\\d+)(?:\\.(\\d+))?\'

   # Override the version guessing with an explicit version
   #
   version: 5.9


Reporting `SourceInfo <https://docs.buildstream.build/master/buildstream.source.html#buildstream.source.SourceInfo>`_
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
The git_module source reports the full URL of the git repository as the *url*.

Further, the git_module source reports the `SourceInfoMedium.GIT
<https://docs.buildstream.build/master/buildstream.source.html#buildstream.source.SourceInfoMedium.GIT>`_
*medium* and the `SourceVersionType.COMMIT
<https://docs.buildstream.build/master/buildstream.source.html#buildstream.source.SourceVersionType.COMMIT>`_
*version_type*, for which it reports the commit sha as the *version*.

If the ref is found to be in ``git-describe`` format, an attempt to guess the version based on the
git tag portion of the ref will be made for the reporting of the *guess_version*. Control over how
the guess is made or overridden is controlled based on the ``version-guess-pattern`` and ``version``
configuration attributes described above.

In order to understand how the ``version-guess-pattern`` works, please refer to the documentation
for `utils.guess_version() <https://docs.buildstream.build/master/buildstream.source.html#buildstream.utils.guess_version>`_

In the case that a git describe string represents a commit that is beyond the tag portion
of the git describe reference (i.e. the version is not exact), then the number of commits
found beyond the tag will be reported in the ``commit-offset`` field of the *extra_data*.
"""
import os

from buildstream import SourceError

from .git_tag import AbstractGitTagSource, GitTagMirror


class GitModuleSource(AbstractGitTagSource):
    # pylint: disable=attribute-defined-outside-init

    BST_REQUIRES_PREVIOUS_SOURCES_TRACK = True

    def get_extra_unique_key(self):
        key = []

        # Distinguish different submodules that reference the same commit
        if self.path:
            key.append({"path": self.path})
        return key

    def get_extra_config_keys(self):
        return ["path"]

    def extra_configure(self, node):
        ref = node.get_str("ref", None)

        self.path = node.get_str("path", None)
        if os.path.isabs(self.path):
            self.path = os.path.relpath(self.path, "/")
        self.mirror = GitTagMirror(
            self,
            self.path,
            self.original_url,
            ref,
            primary=True,
            full_clone=self.full_clone,
            guesser=self.guesser,
        )

    def track(self, previous_sources_dir):
        # list objects in the parent repo tree to find the commit
        # object that corresponds to the submodule
        _, output = self.check_output(
            [self.host_git, "submodule", "status", self.path],
            fail=f"{self}: Failed to run 'git submodule status {self.path}'",
            cwd=previous_sources_dir,
        )

        fields = output.split()
        if not fields:
            raise SourceError(
                f"{self}: Could not find submodule at path {self.path}. Please check the submodule exists within the Git repository."
            )
        commit = fields[0].lstrip("-+")
        if len(commit) != 40:
            raise SourceError(
                f"{self}: Unexpected output from 'git submodule status'"
            )

        return commit

    def get_source_fetchers(self):
        yield self.mirror


def setup():
    return GitModuleSource
