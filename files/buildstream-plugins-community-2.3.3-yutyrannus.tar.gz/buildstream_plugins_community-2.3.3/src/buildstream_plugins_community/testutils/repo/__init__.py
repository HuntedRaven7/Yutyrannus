from .ostreerepo import OSTree
from .gitrepo import Git
from .ziprepo import Zip
